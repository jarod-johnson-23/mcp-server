<?php

namespace McpWp\Tests;

use McpWp\Tests_Includes\TestCase;

class PluginTest extends TestCase {
	public function test_plugin(): void {
		$this->assertTrue( true );
	}
}
